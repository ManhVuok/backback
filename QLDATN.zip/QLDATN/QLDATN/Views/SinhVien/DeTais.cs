﻿namespace QLDATN.Views.SinhVien
{
    public class DeTais
    {
    }
}
