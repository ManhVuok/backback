﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

public class QuanLyController : Controller
{
    private readonly DoAnContext _context;

    public QuanLyController(DoAnContext context)
    {
        _context = context;
    }

    // Trang chính admin với thống kê
    public IActionResult Index()
    {
        var tong = _context.DangKys.Count();
        var daDuyet = _context.DangKys.Count(d => d.DuocDuyet);
        var choDuyet = tong - daDuyet;

        ViewBag.Tong = tong;
        ViewBag.DaDuyet = daDuyet;
        ViewBag.ChoDuyet = choDuyet;

        return View();
    }

    // Danh sách sinh viên đã đăng ký
    public IActionResult DanhSachDangKy()
    {
        var danhSach = _context.DangKys
            .Include(dk => dk.SinhVien)
            .Include(dk => dk.DeTai)
                .ThenInclude(dt => dt.GiangVien)
            .OrderBy(dk => dk.NgayDangKy)
            .ToList();

        return View(danhSach);
    }

    // Duyệt hoặc bỏ duyệt
    [HttpPost]
    public IActionResult DuyetDangKy(int id)
    {
        var dk = _context.DangKys.FirstOrDefault(d => d.DangKyId == id);
        if (dk != null)
        {
            dk.DuocDuyet = !dk.DuocDuyet;
            _context.SaveChanges();
        }

        return RedirectToAction("DanhSachDangKy");
    }
}