﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

public class DeTaiController : Controller
{
    private readonly DoAnContext _context;

    public DeTaiController(DoAnContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var list = _context.DeTais.Include(d => d.GiangVien).ToList();
        return View(list);
    }

    public IActionResult Create()
    {
        ViewBag.GiangVienId = new SelectList(_context.GiangViens, "GiangVienId", "HoTen");
        return View();
    }

    [HttpPost]
    public IActionResult Create(DeTai dt)
    {
        if (ModelState.IsValid)
        {
            _context.Add(dt);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        ViewBag.GiangVienId = new SelectList(_context.GiangViens, "GiangVienId", "HoTen", dt.GiangVienId);
        return View(dt);
    }

    public IActionResult Edit(int id)
    {
        var dt = _context.DeTais.Find(id);
        if (dt == null) return NotFound();

        ViewBag.GiangVienId = new SelectList(_context.GiangViens, "GiangVienId", "HoTen", dt.GiangVienId);
        return View(dt);
    }

    [HttpPost]
    public IActionResult Edit(DeTai dt)
    {
        if (ModelState.IsValid)
        {
            _context.Update(dt);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        ViewBag.GiangVienId = new SelectList(_context.GiangViens, "GiangVienId", "HoTen", dt.GiangVienId);
        return View(dt);
    }

    public IActionResult Delete(int id)
    {
        var dt = _context.DeTais.Find(id);
        return dt == null ? NotFound() : View(dt);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        var dt = _context.DeTais.Find(id);
        if (dt != null)
        {
            _context.DeTais.Remove(dt);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}