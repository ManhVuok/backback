﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class GiangVienController : Controller
{
    private readonly DoAnContext _context;

    public GiangVienController(DoAnContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        if (HttpContext.Session.GetString("VaiTro") != "Admin")
            return RedirectToAction("DangNhap", "TaiKhoan");

        return View(_context.GiangViens.ToList());
    }

    public IActionResult Create() => View();

    [HttpPost]
    public IActionResult Create(GiangVien gv)
    {
        if (ModelState.IsValid)
        {
            _context.GiangViens.Add(gv);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(gv);
    }

    public IActionResult Edit(int id)
    {
        var gv = _context.GiangViens.Find(id);
        return gv == null ? NotFound() : View(gv);
    }

    [HttpPost]
    public IActionResult Edit(GiangVien gv)
    {
        if (ModelState.IsValid)
        {
            _context.Update(gv);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(gv);
    }

    public IActionResult Delete(int id)
    {
        var gv = _context.GiangViens.Find(id);
        return gv == null ? NotFound() : View(gv);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        var gv = _context.GiangViens.Find(id);
        if (gv != null)
        {
            _context.GiangViens.Remove(gv);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}