using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly DoAnContext _context;

    public HomeController(ILogger<HomeController> logger, DoAnContext context)
    {
        _logger = logger;
        _context = context;
    }

    public IActionResult Index()
    {
        ViewBag.SoSinhVien = _context.SinhViens.Count();
        ViewBag.SoGiangVien = _context.GiangViens.Count();
        ViewBag.SoDeTai = _context.DeTais.Count();
        ViewBag.SoDangKy = _context.DangKys.Count();

        return View();
    }

    // C�c action kh�c gi? nguy�n
}