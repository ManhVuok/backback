﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class DangKyController : Controller
{
    private readonly DoAnContext _context;

    public DangKyController(DoAnContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        if (HttpContext.Session.GetString("VaiTro") != "SinhVien")
            return RedirectToAction("DangNhap", "TaiKhoan");

        var danhSachDeTai = _context.DeTais.Include(d => d.GiangVien).ToList();
        return View(danhSachDeTai);
    }

    [HttpPost]
    [ValidateAntiForgeryToken] // ✅ KHÔNG được thiếu dòng này
    public IActionResult DangKyDeTai(int DeTaiId)
    {
        var vaiTro = HttpContext.Session.GetString("VaiTro");
        var sinhVienId = HttpContext.Session.GetInt32("SinhVienId");

        if (vaiTro != "SinhVien" || sinhVienId == null)
            return RedirectToAction("DangNhap", "TaiKhoan");

        bool daDangKy = _context.DangKys.Any(x => x.SinhVienId == sinhVienId);

        if (daDangKy)
        {
            TempData["ThongBao"] = "⚠ Bạn đã đăng ký đề tài rồi.";
            return RedirectToAction("Index");
        }

        var dk = new DangKy
        {
            SinhVienId = sinhVienId.Value,
            DeTaiId = DeTaiId,
            NgayDangKy = DateTime.Now,
            DuocDuyet = false
        };

        _context.DangKys.Add(dk);
        _context.SaveChanges();

        TempData["ThongBao"] = "✔️ Đăng ký thành công!";
        return RedirectToAction("Index");
    }
}