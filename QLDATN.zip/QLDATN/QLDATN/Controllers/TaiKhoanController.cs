﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Linq;

public class TaiKhoanController : Controller
{
    private readonly DoAnContext _context;

    public TaiKhoanController(DoAnContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult DangNhap()
    {
        return View();
    }

    [HttpPost]
    public IActionResult DangNhap(string tenDangNhap, string matKhau)
    {
        // ✅ Trim để tránh lỗi do nhập dấu cách
        tenDangNhap = tenDangNhap?.Trim();
        matKhau = matKhau?.Trim();

        // ✅ In log debug
        Console.WriteLine($">> Nhập user: [{tenDangNhap}], pass: [{matKhau}]");

        var user = _context.NguoiDungs
            .FirstOrDefault(u => u.TenDangNhap == tenDangNhap && u.MatKhau == matKhau);

        if (user == null)
        {
            ViewBag.ThongBao = "❌ Sai tên đăng nhập hoặc mật khẩu!";
            return View();
        }

        // ✅ Gán session
        HttpContext.Session.SetInt32("NguoiDungId", user.NguoiDungId);
        HttpContext.Session.SetString("TenDangNhap", user.TenDangNhap);
        HttpContext.Session.SetString("VaiTro", user.VaiTro);

        // ✅ Điều hướng theo vai trò
        switch (user.VaiTro)
        {
            case "SinhVien":
                var sv = _context.SinhViens
                    .FirstOrDefault(s => s.NguoiDungId == user.NguoiDungId);
                if (sv != null)
                {
                    HttpContext.Session.SetInt32("SinhVienId", sv.SinhVienId);
                    Console.WriteLine(">> ✅ SinhVienId = " + sv.SinhVienId);
                    return RedirectToAction("Index", "DangKy");
                }
                else
                {
                    ViewBag.ThongBao = "⚠ Tài khoản chưa liên kết với sinh viên nào.";
                    return View();
                }

            case "GiangVien":
                return RedirectToAction("TrangCaNhan", "GiangVien");

            case "Admin":
                return RedirectToAction("Index", "QuanLy");

            default:
                ViewBag.ThongBao = "⚠ Vai trò không xác định.";
                return View();
        }
    }

    public IActionResult DangXuat()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("DangNhap");
    }
}