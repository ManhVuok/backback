﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class SinhVienController : Controller
{
    private readonly DoAnContext _context;

    public SinhVienController(DoAnContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        if (HttpContext?.Session.GetString("VaiTro") == null)
            return RedirectToAction("DangNhap", "TaiKhoan");

        return View(_context!.SinhViens.ToList());
    }

    public IActionResult Details(int id)
    {
        var sv = _context.SinhViens
            .Include(s => s.DangKys!)
            .ThenInclude(dk => dk.DeTai)
            .FirstOrDefault(s => s.SinhVienId == id);

        return sv == null ? NotFound() : View(sv);
    }

    public IActionResult Create() => View();

    [HttpPost]
    public IActionResult Create(SinhVien sv)
    {
        if (ModelState.IsValid)
        {
            _context.SinhViens.Add(sv);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(sv);
    }

    public IActionResult Edit(int id)
    {
        var sv = _context.SinhViens.Find(id);
        return sv == null ? NotFound() : View(sv);
    }

    [HttpPost]
    public IActionResult Edit(SinhVien sv)
    {
        if (ModelState.IsValid)
        {
            _context.Update(sv);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(sv);
    }

    public IActionResult Delete(int id)
    {
        var sv = _context.SinhViens.Find(id);
        return sv == null ? NotFound() : View(sv);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        var sv = _context.SinhViens.Find(id);
        if (sv != null)
        {
            _context.SinhViens.Remove(sv);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}