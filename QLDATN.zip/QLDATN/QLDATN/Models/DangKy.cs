﻿public class DangKy
{
    public int DangKyId { get; set; }

    public int SinhVienId { get; set; }
    public SinhVien? SinhVien { get; set; }

    public int DeTaiId { get; set; }
    public DeTai? DeTai { get; set; }

    public DateTime NgayDangKy { get; set; }
    public bool DuocDuyet { get; set; }
}