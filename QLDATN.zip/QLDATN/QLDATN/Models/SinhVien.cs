﻿public class SinhVien
{
    public int SinhVienId { get; set; }

    public string HoTen { get; set; } = string.Empty;

    public string Lop { get; set; } = string.Empty;

    public int NguoiDungId { get; set; }

    public NguoiDung? NguoiDung { get; set; }

    public ICollection<DangKy> DangKys { get; set; } = new List<DangKy>();
}