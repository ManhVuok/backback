﻿public class NguoiDung
{
    public int NguoiDungId { get; set; }
    public string TenDangNhap { get; set; } = string.Empty;
    public string MatKhau { get; set; } = string.Empty;
    public string VaiTro { get; set; } = string.Empty; // "Admin", "GiangVien", "SinhVien"
}