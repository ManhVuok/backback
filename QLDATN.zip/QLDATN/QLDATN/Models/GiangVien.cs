﻿using QLDATN.Models;

public class GiangVien
{
    public int GiangVienId { get; set; }
    public string HoTen { get; set; } = string.Empty;
    public string BoMon { get; set; } = string.Empty;
    public ICollection<DeTai>? DeTais { get; set; }
}