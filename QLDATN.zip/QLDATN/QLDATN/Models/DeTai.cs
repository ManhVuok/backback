﻿using QLDATN.Models;

public class DeTai
{
    public int DeTaiId { get; set; }
    public string TenDeTai { get; set; } = string.Empty;
    public string MoTa { get; set; } = string.Empty;
    public int? GiangVienId { get; set; }
    public GiangVien? GiangVien { get; set; }
    public ICollection<DangKy>? DangKys { get; set; }
}