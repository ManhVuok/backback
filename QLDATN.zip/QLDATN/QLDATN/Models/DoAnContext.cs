﻿using Microsoft.EntityFrameworkCore;

public class DoAnContext : DbContext
{
    public DoAnContext(DbContextOptions<DoAnContext> options) : base(options) { }

    public DbSet<SinhVien> SinhViens { get; set; }
    public DbSet<GiangVien> GiangViens { get; set; }
    public DbSet<DeTai> DeTais { get; set; }
    public DbSet<DangKy> DangKys { get; set; }
    public DbSet<NguoiDung> NguoiDungs { get; set; }
}